#!/usr/bin/env bash
. devel/setup.bash
rosrun rviz rviz -d ./src/sick_scan/launch/rviz/radar_combi.rviz
