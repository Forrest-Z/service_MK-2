sudo mkdir /media/ramdisk
sudo mount -t tmpfs none /media/ramdisk
set ROS_DISTRO=melodic
source ./devel/setup.bash

