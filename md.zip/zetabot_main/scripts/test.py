#!/usr/bin/env python
from enum import Enum
import librealsense2


class test :
    sonar1 = 1
    sonar2 = 2
    sonar3 = 3
    sonar4 = 4

for i in test :
    print(i)


if  sensor1 + sensor2 == senosor3 :
    go_left()
    