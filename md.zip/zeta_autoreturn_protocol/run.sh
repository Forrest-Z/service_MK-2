#!/bin/bash

/usr/bin/python zeta_autoreturn_notcp_py2.py

